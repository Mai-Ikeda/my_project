<!doctype html>
<html lang="<?php echo e(app()->getLocale()); ?>">

<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
    <title><?php echo e($viewUseVariables["pageTitle"]); ?></title>
    <link rel="stylesheet" href="/css/common/animations.css">

    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/hooper@0.2.1/dist/hooper.css">
    <script src="https://cdn.jsdelivr.net/npm/hooper@0.2.1/dist/hooper.min.js"></script>
</head>

<?php echo $__env->make('template/common/layout_base_font', compact( "viewUseVariables" ) , \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<style>
    * {
        /* font-family: "ＭＳ Ｐ明朝", "MS PMincho", "ヒラギノ明朝 Pro W3", "Hiragino Mincho Pro", serif; */
        margin: 0px;
        border: none;
    }

    body {
        background-color: black;
    }

    main {
        margin: 0 auto;
        background-color: white;
        background-image: url("<?php echo e(S3_IMG_URL); ?>/guest/background.jpg");
        background-repeat: repeat-y;
    }

    .fit-parent-max {
        width: 100%;
    }

    input.text-form {
        width: 60%;
        padding: 4px;
        margin: 12px;
        font-size: 120%;
        text-align: center;
        border: 1px solid #0005;
        border-radius: 5px;
        color: -internal-light-dark(black, white);
        background-color: white;
    }

    select.select-form {
        padding: 4px;
        margin: 12px;
        font-size: 120%;
        text-align: center;
        border: 1px solid black;
        border-radius: 5px;
        color: -internal-light-dark(black, white);
        background-color: white;
        appearance: menulist;
    }

    div.common-window-background {
        background-image: url("<?php echo e(S3_IMG_URL); ?>/member/common_window_background.jpg");
        background-repeat: repeat-y;
        text-align: center;
        margin: -2% 0;
        padding: 2% 0;
    }

    div.first-view-background {
        position: relative;
        width: 100%;
    }

    div.first-view-background button {
        position: absolute;
        width: 50%;
        left: 25%;
        right: 25%;
        bottom: 0;
    }

    div.first-view-background button img {
        width: 100%;
    }

    button.join-button {
        width: 70%;
        margin-left: 15%;
    }

    button.join-button img {
        width: 100%;
    }

    div.guest-join-button {
        width: 100%;
        margin-top: 1em;
        text-align: center;
        color: blue;
        text-decoration: underline;
    }

    button.appraisal-button {
        width: 40%;
    }
</style>

<?php echo $__env->make('template/common/layout_switch', compact( "viewUseVariables" ) , \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<body>
    <script>
        //------------------------------//
        // php -> js への変数渡し ここから
        //------------------------------//
    </script>

    <main id="memberIndex">

        <section name="banner">
            <img class="fit-parent-max" src="<?php echo e(S3_IMG_URL); ?>/member/banner.jpg">
        </section>

        <?php echo $__env->make('template/member/index/daily_fortune', compact( "viewUseVariables" ) , \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <?php echo $__env->make('template/member/index/todays_fortune', compact( "viewUseVariables" ) , \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <?php echo $__env->make('template/member/index/banner_pickup', compact( "viewUseVariables" ) , \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <?php echo $__env->make('template/member/index/calendar_mini', compact( "viewUseVariables" ) , \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <?php echo $__env->make('template/member/index/paper_fortune', compact( "viewUseVariables" ) , \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <?php echo $__env->make('template/member/index/trouble_solving', compact( "viewUseVariables" ) , \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <?php echo $__env->make('template/member/index/pickup_menu', compact( "viewUseVariables" ) , \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <?php echo $__env->make('template/member/index/new_menu', compact( "viewUseVariables" ) , \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    </main>
    <script src="/js/member/index/index.js"></script>
</body>

</html><?php /**PATH /var/www/laravell_project/resources/views/member/index.blade.php ENDPATH**/ ?>