<?php if (!$viewUseVariables["isMobile"]) { ?>
    <style>
        body {
            width: 600px;
            margin: 0 auto;
        }
    </style>
<?php } ?><?php /**PATH /var/www/laravell_project/resources/views/template/common/layout_switch.blade.php ENDPATH**/ ?>