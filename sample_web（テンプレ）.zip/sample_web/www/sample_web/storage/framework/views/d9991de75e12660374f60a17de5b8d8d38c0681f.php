<section name="firstViewShort">
    <div class="partition">
        <div class="partition__border"></div>
    </div>
    <div class="fv-short">
        <a href="/wiki">
            <span class="fv-short__title">
                <p class="fv-short__title__head">上級者に聞いてみた</p>
                <p class="fv-short__title__center">BBPS4 攻略情報 wiki</p>
            </span>
        </a>
    </div>
    <div class="partition">
        <div class="partition__border"></div>
    </div>
</section>
<?php /**PATH /var/www/kms_content/resources/views/template/common/first_view_short.blade.php ENDPATH**/ ?>