<section id="header" name="header" class="header">
    <div class="header__main">

        <transition name="slide-left-fade-large">
            <div v-show="show" class="header__main__buttons">
                <div class="header__main__buttons__button">
                    <a @click="control()" href="/wiki#pageList1">・マップ別攻略</a>
                    <div class="header__main__buttons__button__underline"></div>
                </div>
                <div class="header__main__buttons__button">
                    <a @click="control()" href="/wiki#pageList2">・強襲兵装</a>
                    <div class="header__main__buttons__button__underline"></div>
                </div>
                <div class="header__main__buttons__button">
                    <a @click="control()" href="/wiki#pageList3">・重火力兵装</a>
                    <div class="header__main__buttons__button__underline"></div>
                </div>
                <div class="header__main__buttons__button">
                    <a @click="control()" href="/wiki#pageList4">・遊撃兵装</a>
                    <div class="header__main__buttons__button__underline"></div>
                </div>
                <div class="header__main__buttons__button">
                    <a @click="control()" href="/wiki#pageList5">・支援兵装</a>
                    <div class="header__main__buttons__button__underline"></div>
                </div>
                <div class="header__main__buttons__button">
                    <a @click="control()" href="/wiki#pageList6">・ユニオン攻略</a>
                    <div class="header__main__buttons__button__underline"></div>
                </div>
            </div>
        </transition>

        <img @click="control()" src="/kms_content/images/wiki/header_menu.png" class="header__main__icon" />

    </div>
</section>

<style>
    main {
        padding-top: 8vh;
    }
</style><?php /**PATH /var/www/kms_content/resources/views/template/common/header.blade.php ENDPATH**/ ?>