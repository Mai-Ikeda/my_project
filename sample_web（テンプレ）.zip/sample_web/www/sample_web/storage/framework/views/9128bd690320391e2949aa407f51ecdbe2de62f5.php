<style>
    div.calendar-center {
        background-color: white;
        margin: -2% 0;
        padding: 2% 0;
    }

    div.calendar {
        display: flex;
        justify-content: center;
        margin: 5px 0;
        border: rgba(0, 0, 0, 0.1) 2px solid;
    }

    div.calendar div {
        width: calc(100% / 9);
        margin: calc((100% / 9 / 20));
        color: white;
        background-color: rgba(0, 0, 0, 0.1);
        font-size: 100%;
    }

    div.calendar div .calendar-day-of-the-week {
        width: 100%;
        margin: 2% 0;
        background-color: #130b56;
        text-align: center;
    }

    div.calendar div .calendar-day {
        width: 50%;
        margin: 2% 0;
        background-color: #130b56;
        text-align: center;
    }

    div.calendar div .calendar-direction {
        width: 100%;
        margin: 2% 0;
        background-color: #7b671b;
        text-align: center;
    }

    div.calendar-show-next {
        position: relative;
    }

    div.calendar-show-next img {
        position: absolute;
        width: 50%;
        right: 0;
    }
</style>

<section name="calendarMini">
    <img class="fit-parent-max" src="<?= S3_IMG_URL ?>/member/calendar_head.jpg">
    <div class="calendar-center">
        <?php
        $dayOfTheWeeks = ["日", "月", "火", "水", "木", "金", "土"];
        ?>

        <div class="calendar">
            <?php for ($i = 0; $i < 7; $i++) { ?>
                <div style="<?php echo $i == 0 ? "border:#af2d20b5 4px solid;" : "border:#0000 4px solid;" ?>">
                    <div class="calendar-day-of-the-week" style="<?php echo $i == 0 ? "background-color:red;" : "" ?>">
                        <p><?= $dayOfTheWeeks[$i] ?></p>
                    </div>
                    <div class="calendar-day">
                        <p><?= $i ?></p>
                    </div>
                    <div class="calendar-direction">
                        <p><?= "南東" ?></p>
                    </div>
                    <div class="calendar-direction">
                        <p><?= "北" ?></p>
                    </div>
                </div>
            <?php } ?>
        </div>
    </div>
    <!-- /calendar-center -->

    <div class="calendar-show-next">
        <img src="<?= S3_IMG_URL ?>/member/calendar_show_next.png">
    </div>
    <!-- /calendar-show-next -->

    <img class="fit-parent-max" src="<?= S3_IMG_URL ?>/member/calendar_bottom.jpg">
</section>
<!-- /calendarMini --><?php /**PATH /var/www/laravell_project/resources/views/template/member/index/calendar_mini.blade.php ENDPATH**/ ?>