<!doctype html>
<html lang="<?php echo e(app()->getLocale()); ?>">

<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
    <title>contentsInfo更新</title>
    <link rel="stylesheet" href="/css/guest_index.css">
</head>

<body>
    <main>
        <section>
            <?php echo e($viewUseVariables["contentsInfoUpdateResult"]); ?>

        </section>
    </main>
</body>

</html><?php /**PATH /var/www/laravell_project/resources/views/management/reflesh_contents_info.blade.php ENDPATH**/ ?>