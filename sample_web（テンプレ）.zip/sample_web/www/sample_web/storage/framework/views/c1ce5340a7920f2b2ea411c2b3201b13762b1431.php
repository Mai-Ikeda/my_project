<?php if ( !$viewUseVariables["isMobile"]) { ?>
    <style>
        body {
            width: 600px;
            margin: 0 auto;
        }
    </style>
<?php } ?><?php /**PATH /var/www/kms_content/resources/views/template/wiki/layout_switch.blade.php ENDPATH**/ ?>