<style>
    div.trouble-solving-center {
        background-image: url("<?= S3_IMG_URL ?>/member/trouble_solving_center.jpg");
        background-size: 100% auto;
        background-repeat: repeat-y;
        margin: -2% 0;
        padding: 2% 0;
        font-size: 120%;
        text-align: center;
    }

    div.trouble-solving-welcome-message {
        color: #585858;
        font-weight: bold;
    }

    button.trouble-solving-menu {
        color: white;
        width: 80%;
        margin: 1em auto;
        padding: 0.5em;
        border-radius: 0.2em;
        box-shadow: 0px 0.1em 0.1em #606060;
        background-image: linear-gradient(#828282 0%, #393939 100%);
        font-size: 110%;
    }

    button.trouble-solving-menu-pickup {
        color: white;
        width: 80%;
        margin: 1em auto;
        padding: 0.5em;
        border-radius: 0.2em;
        box-shadow: 0px 1px 1px #606060;
        background-image: linear-gradient(#a075c5 0%, #523067 100%);
        font-size: 110%;
    }

    button.trouble-solving-show-next {
        width: 70%;
    }
    button.trouble-solving-show-next img {
        width: 100%;
    }
</style>

<section id="troubleSolving" name="troubleSolving">
    <img class="fit-parent-max" src="<?= S3_IMG_URL ?>/member/trouble_solving_head.jpg">
    <div class="trouble-solving-center">
        <p class="trouble-solving-welcome-message">どこもてすたろう2さん<br>今日のあなたのお悩みは？</p>
        
        <button @click="clickTroubleSolvingButton(0)" name="troubleSolvingButton" class="trouble-solving-menu"></button>
        <button @click="clickTroubleSolvingButton(1)" name="troubleSolvingButton" class="trouble-solving-menu"></button>
        <button @click="clickTroubleSolvingButton(2)" name="troubleSolvingButton" class="trouble-solving-menu-pickup"></button>

        <button class="trouble-solving-show-next" @click="change()">
            <img src="<?= S3_IMG_URL ?>/member/trouble_solving_button.png">
        </button>
        <!-- /trouble-solving-show-next -->

    </div>
    <!-- /trouble-solving-center -->

    <img class="fit-parent-max" src="<?= S3_IMG_URL ?>/member/trouble_solving_bottom.jpg">
</section>
<!-- /troubleSolving -->

<script>
    var troubleSolvingDatas = <?php echo json_encode($viewUseVariables["troubleSolvingDatas"]["new_onayami"] ); ?>;
</script>
<?php /**PATH /var/www/laravell_project/resources/views/template/member/index/trouble_solving.blade.php ENDPATH**/ ?>