<style>
    div.paper-fortune-center {
        background-image: url("<?= S3_IMG_URL ?>/member/paper_fortune_center.jpg");
        background-size: 100% auto;
        background-repeat: repeat-y;
        margin: -2% 0;
        padding: 2% 0;
        text-align: center;
    }

    button.paper-fortune-button {
        width: 100%;
        mix-blend-mode: multiply;
    }

    .paper-fortune-animation {
        animation: move-up-down 1s infinite alternate ease-in-out;
        display: inline-block;
    }
</style>

<section name="paperFortune">
    <img class="fit-parent-max" src="<?= S3_IMG_URL ?>/member/paper_fortune_head.jpg">
    <div class="paper-fortune-center">
        <button class="paper-fortune-button paper-fortune-animation">
            <img class="fit-parent-max" src="<?= S3_IMG_URL ?>/member/paper_fortune_button.png">
        </button>
    </div>
    <!-- /paper-fortune-center -->

    <img class="fit-parent-max" src="<?= S3_IMG_URL ?>/member/paper_fortune_bottom.jpg">
</section>
<!-- /paperFortune --><?php /**PATH /var/www/laravell_project/resources/views/template/member/index/paper_fortune.blade.php ENDPATH**/ ?>