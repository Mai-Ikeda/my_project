<style>
    div.daily-fortune-buttons {
        display: flex;
        justify-content: center;
    }

    div.daily-fortune-buttons button {
        width: 30%;
        margin: 0px;
        padding: 0px;
    }

    div.daily-fortune-buttons button img {
        width: 100%;
        height: 100%;
    }

    div.daily-fortune-buttons button:nth-child(1) {
        background-image: url("<?php echo e(S3_IMG_URL); ?>/member/daily_fortune_button1_off.png");
        background-size: 100% 100%;
    }

    div.daily-fortune-buttons button:nth-child(2) {
        background-image: url("<?php echo e(S3_IMG_URL); ?>/member/daily_fortune_button2_off.png");
        background-size: 100% 100%;
    }

    div.daily-fortune-buttons button:nth-child(3) {
        background-image: url("<?php echo e(S3_IMG_URL); ?>/member/daily_fortune_button3_off.png");
        background-size: 100% 100%;
    }

    div.daily-fortune-texts {
        position: relative;
        width: 80%;
        margin: 0 auto;
        text-align: left;
    }

    div.daily-fortune-texts span {
        position: absolute;
    }

    div.daily-fortune-show-next {
        width: 80%;
        margin: auto;
        text-align: right;
    }

    input.show-next {
        color: blue;
        background-color: transparent;
        text-decoration: underline;
    }
</style>

<section id="dailyFortune" name="dailyFortune">
    <img class="fit-parent-max" src="<?php echo e(S3_IMG_URL); ?>/member/daily_fortune_head.jpg">
    <div class="common-window-background">
        <form name="dailyFortuneShowNextForm" class="daily-fortune-show-next-form" action="javascript:void(0);">
            <input name="dailyFortuneSelectingLuck" type="hidden" v-model="selectingId">
            <div name="dailyFortuneTexts" class="daily-fortune-texts">
                <span name="dailyFortuneText" data-id="1" class="fadein">
                    <?= "aiueo" ?>…
                    <input class="show-next" type="submit" value="続きを見る">
                </span>
                <span name="dailyFortuneText" data-id="2" class="fadeout">
                    <?= "kakikukeko" ?>…
                    <input class="show-next" type="submit" value="続きを見る">
                </span>
                <span name="dailyFortuneText" data-id="3" class="fadeout">
                    <?= "sasisu<br>seso" ?>…
                    <input class="show-next" type="submit" value="続きを見る">
                </span>
            </div>
            <!-- /dailyFortuneTexts -->
        </form>
        <!-- /dailyFortuneShowNextForm -->

        <div name="dailyFortuneButtons" class="daily-fortune-buttons">
            <button name="dailyFortuneButton" @click="setDailyFortuneSelectingId(1)">
                <img name="dailyFortuneButtonImage" data-id="1" class="fadein" src="<?php echo e(S3_IMG_URL); ?>/member/daily_fortune_button1_on.png">
            </button>
            <button name="dailyFortuneButton" @click="setDailyFortuneSelectingId(2)">
                <img name="dailyFortuneButtonImage" data-id="2" class="fadeout" src="<?php echo e(S3_IMG_URL); ?>/member/daily_fortune_button2_on.png">
            </button>
            <button name="dailyFortuneButton" @click="setDailyFortuneSelectingId(3)">
                <img name="dailyFortuneButtonImage" data-id="3" class="fadeout" src="<?php echo e(S3_IMG_URL); ?>/member/daily_fortune_button3_on.png">
            </button>
        </div>
        <!-- /dailyFortuneButtons -->
    </div>
    <!-- /common-window-background -->
    <img class="fit-parent-max" src="<?php echo e(S3_IMG_URL); ?>/member/daily_fortune_bottom.jpg">
</section>
<!-- /dailyFortune --><?php /**PATH /var/www/laravell_project/resources/views/template/member/index/daily_fortune.blade.php ENDPATH**/ ?>