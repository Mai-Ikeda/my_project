<!doctype html>
<html lang="<?php echo e(app()->getLocale()); ?>">

<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
    <title></title>
</head>

<body>
    <section id="wiki">
        <div v-html="html"></div>

        <test-component text="Laravel!!"></test-component>
    </section>

    <script src="/larabel_ts_vue_template/js/build/wiki/index/index.js"></script>
</body>

</html><?php /**PATH /var/www/larabel_ts_vue_template/resources/views/wiki/index.blade.php ENDPATH**/ ?>