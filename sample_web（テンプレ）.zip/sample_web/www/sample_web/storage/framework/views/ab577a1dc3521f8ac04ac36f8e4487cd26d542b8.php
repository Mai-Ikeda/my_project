<!doctype html>
<html lang="<?php echo e(app()->getLocale()); ?>">

<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
    <title></title>
    <link rel="stylesheet" href="/kms_content/css/init.css">
    <link rel="stylesheet" href="/kms_content/css/common/animations.css">
    <link rel="stylesheet" href="/kms_content/css/common/unique_animations.css">
    <link rel="stylesheet" href="/kms_content/css/build/common/index.css">
    <link rel="stylesheet" href="/kms_content/css/build/wiki/content/index.css">
</head>

<?php

use App\Enums\WikiContentCategory;
use App\Models\WikiContent;

$keys = WikiContent::Keys();

?>

<body>
    <script>
        //------------------------------//
        // php -> js への変数渡し ここから
        //------------------------------//
    </script>

    <?php echo $__env->make('template/common/header', compact( "viewUseVariables" ) , \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    <main>
        <section id="loadingLid">
            <transition name="fade">
                <div v-show="show" class="loading-lid">
                    <div class="loading-lid__icon"></div>
                </div>
            </transition>
        </section>

        <?php if (empty($viewUseVariables["content"])) {
            echo "page 404 not found.";
            return;
        } ?>

        <?php echo $__env->make('template/common/first_view_short', compact( "viewUseVariables" ) , \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

        <section name="contentTitle">
            <div class="content-title">
                <div class="content-title__text">
                    <?= $viewUseVariables["content"]["title"] ?>
                    <br>
                    <span class="content-title__text__name">
                        <?= $viewUseVariables["content"]["nickname"] ?>
                    </span>
                </div>
            </div>
            <div class="partition">
                <div class="partition__border"></div>
            </div>
        </section>

        <section id="contentBody" class="cb">
            <div class="cb__main">
                <?= $viewUseVariables["content"]["body"] ?>
            </div>
        </section>

        <section id="index"></section>
    </main>
    <script src="/kms_content/js/build/common/index.js"></script>
    <script src="/kms_content/js/build/wiki/content/index.js"></script>
</body>

</html><?php /**PATH /var/www/kms_content/resources/views/wiki/content.blade.php ENDPATH**/ ?>