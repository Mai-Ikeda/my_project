<!doctype html>
<html lang="<?php echo e(app()->getLocale()); ?>">

<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
    <title></title>
    <link rel="stylesheet" href="/css/init.css">
    <link rel="stylesheet" href="/css/build/wiki/index/index.css">
</head>

<body>
    <script>
        //------------------------------//
        // php -> js への変数渡し ここから
        //------------------------------//
    </script>

    <main>
        <section name="firstView">
            <div class="partition">
                <div class="partition__border"></div>
            </div>
            <div class="fv">
                <span class="fv__title">
                    <p class="fv__title__head">上級者に聞いてみた</p>
                    <p class="fv__title__center">BBPS4</p>
                    <div class="fv__title__bottom">攻略情報 wiki</div>
                </span>
            </div>
            <div class="partition">
                <div class="partition__border"></div>
            </div>
        </section>

        <section name="armySectionJump">
            <div class="asj">
                <div class="asj__ass">
                    <span>
                        強襲兵装<br>▼
                    </span>
                </div>
                <div class="asj__hea">
                    <span>
                        重火力兵装<br>▼
                    </span>
                </div>
                <div class="asj__sho">
                    <span>
                        遊撃兵装<br>▼
                    </span>
                </div>
                <div class="asj__sup">
                    <span>
                        支援兵装<br>▼
                    </span>
                </div>
            </div>
            <div class="partition-single"></div>
        </section>

        <section name="suiteDescription">
            <div class="sd">

                <div class="sd__title">
                    〜 このサイトについて 〜
                </div>
                <div class="sd__text">
                    このサイトでは PS4 版 BorderBreak 有識者の情報を基軸とした攻略情報を掲載しております。
                    <br>
                    <br>
                    兵装ごとの立ち回りや様々な戦闘ケース、状況、マップ攻略を題材とした情報を掲載しておりますため、よければご覧ください。
                </div>
            </div>
            <div class="partition">
                <div class="partition__border"></div>
            </div>
        </section>

        <section name="mapPageList">
            <div class="partition-mono">
                <div class="partition-mono__title">
                    <div class="partition-mono__title__text">
                        <img src="/images_wiki/images/wiki/army_map.png">
                        マップ攻略
                    </div>
                </div>
                <div class="partition-mono__border"></div>
            </div>

            <div class="page-list">
                <div class="page-list__main">
                    <table class="page-list__main__table">
                        <tr class="page-list__main__table__column">
                            <th>監修</th>
                            <th>タイトル</th>
                        </tr>
                        <tr class="page-list__main__table__line">
                            <td class="page-list__main__table__line__icon">
                                <div><img src="/images_wiki/images/wiki/writer_kuroto.jpg"><br><span>bb_kuroto</span></div>
                            </td>
                            <td class="page-list__main__table__line__title">
                                <div class="page-list__main__table__line__title__text">
                                    <span>城塞都市バレリオ ～飛天交叉～</span>
                                </div>
                                <div class="page-list__main__table__line__title__time">投稿日:2020-03-17</div>
                            </td>
                        </tr>
                    </table>
                </div>
            </div>
        </section>

        <section name="assaultPageList">
            <div class="partition-mono">
                <div class="partition-mono__title">
                    <div class="partition-mono__title__text">
                        <img src="/images_wiki/images/wiki/army_ass.png">
                        強襲兵装
                    </div>
                </div>
                <div class="partition-mono__border"></div>
            </div>

            <div class="page-list">
                <div class="page-list__main">
                    <table class="page-list__main__table">
                        <tr class="page-list__main__table__column">
                            <th>監修</th>
                            <th>タイトル</th>
                        </tr>
                        <tr class="page-list__main__table__line">
                            <td class="page-list__main__table__line__icon">
                                <div><img src="/images_wiki/images/wiki/writer_kuroto.jpg"><br><span>bb_kuroto</span></div>
                            </td>
                            <td class="page-list__main__table__line__title">
                                <div class="page-list__main__table__line__title__text">
                                    <span>強襲兵装の基本思考</span>
                                </div>
                                <div class="page-list__main__table__line__title__time">投稿日:2020-03-13</div>
                            </td>
                        </tr>
                        <tr class="page-list__main__table__line">
                            <td class="page-list__main__table__line__icon">
                                <div><img src="/images_wiki/images/wiki/writer_melonguma.jpg"><br><span>メロングマ</span></div>
                            </td>
                            <td class="page-list__main__table__line__title">
                                <div class="page-list__main__table__line__title__text">
                                    <span>防衛麻の虎の巻</span>
                                </div>
                                <div class="page-list__main__table__line__title__time">投稿日:2020-03-14</div>
                            </td>
                        </tr>
                    </table>
                </div>
            </div>
        </section>

        <section name="heavyPageList">
            <div class="partition-mono">
                <div class="partition-mono__title">
                    <div class="partition-mono__title__text">
                        <img src="/images_wiki/images/wiki/army_hea.png">
                        重火力兵装
                    </div>
                </div>
                <div class="partition-mono__border"></div>
            </div>

            <div class="page-list">
                <div class="page-list__main">
                    <table class="page-list__main__table">
                        <tr class="page-list__main__table__column">
                            <th>監修</th>
                            <th>タイトル</th>
                        </tr>
                        <tr class="page-list__main__table__line">
                            <td class="page-list__main__table__line__icon">
                                <div><img src="/images_wiki/images/wiki/writer_kusumi.jpg"><br><span>くすみ</span></div>
                            </td>
                            <td class="page-list__main__table__line__title">
                                <div class="page-list__main__table__line__title__text">
                                    <span>デブ重の呼吸 戦闘の型</span>
                                </div>
                                <div class="page-list__main__table__line__title__time">投稿日:2020-03-18</div>
                            </td>
                        </tr>
                    </table>
                </div>
            </div>
        </section>

        <section name="shortstopPageList">
            <div class="partition-mono">
                <div class="partition-mono__title">
                    <div class="partition-mono__title__text">
                        <img src="/images_wiki/images/wiki/army_sho.png">
                        遊撃兵装
                    </div>
                </div>
                <div class="partition-mono__border"></div>
            </div>

            <div class="page-list">
                <div class="page-list__main">
                    <table class="page-list__main__table">
                        <tr class="page-list__main__table__column">
                            <th>監修</th>
                            <th>タイトル</th>
                        </tr>
                        <tr class="page-list__main__table__line">
                            <td class="page-list__main__table__line__icon">
                                <div><img src="/images_wiki/images/wiki/writer_kamameshi.jpg"><br><span>かまきら</span></div>
                            </td>
                            <td class="page-list__main__table__line__title">
                                <div class="page-list__main__table__line__title__text">
                                    <span>北極熊をも屠る遊撃の立ち回り</span>
                                </div>
                                <div class="page-list__main__table__line__title__time">投稿日:2020-03-17</div>
                            </td>
                        </tr>
                    </table>
                </div>
            </div>
        </section>

        <section name="supportPageList">
            <div class="partition-mono">
                <div class="partition-mono__title">
                    <div class="partition-mono__title__text">
                        <img src="/images_wiki/images/wiki/army_sup.png">
                        支援兵装
                    </div>
                </div>
                <div class="partition-mono__border"></div>
            </div>

            <div class="page-list">
                <div class="page-list__main">
                    <table class="page-list__main__table">
                        <tr class="page-list__main__table__column">
                            <th>監修</th>
                            <th>タイトル</th>
                        </tr>
                        <tr class="page-list__main__table__line">
                            <td class="page-list__main__table__line__icon">
                                <div><img src="/images_wiki/images/wiki/writer_dokozono.jpg"><br><span>どこぞの室長</span></div>
                            </td>
                            <td class="page-list__main__table__line__title">
                                <div class="page-list__main__table__line__title__text">
                                    <span>罠支援のいろは</span>
                                </div>
                                <div class="page-list__main__table__line__title__time">投稿日:2020-03-15</div>
                            </td>
                        </tr>
                        <tr class="page-list__main__table__line">
                            <td class="page-list__main__table__line__icon">
                                <div><img src="/images_wiki/images/wiki/writer_atomoe.jpg"><br><span>わるいしえん</span></div>
                            </td>
                            <td class="page-list__main__table__line__title">
                                <div class="page-list__main__table__line__title__text">
                                    <span>罠支が複数の時</span>
                                </div>
                                <div class="page-list__main__table__line__title__time">投稿日:2020-03-17</div>
                            </td>
                        </tr>
                    </table>
                </div>
            </div>
        </section>

        <section name="unionPageList">
            <div class="partition-mono">
                <div class="partition-mono__title">
                    <div class="partition-mono__title__text">
                        <img src="/images_wiki/images/wiki/army_union.png">
                        ユニオン攻略
                    </div>
                </div>
                <div class="partition-mono__border"></div>
            </div>

            <div class="page-list">
                <div class="page-list__main">
                    <table class="page-list__main__table">
                        <tr class="page-list__main__table__column">
                            <th>監修</th>
                            <th>タイトル</th>
                        </tr>
                        <tr class="page-list__main__table__line">
                            <td class="page-list__main__table__line__icon">
                                <div><img src="/images_wiki/images/wiki/writer_noel.jpg"><br><span>のえる</span></div>
                            </td>
                            <td class="page-list__main__table__line__title">
                                <div class="page-list__main__table__line__title__text">
                                    <span>サテバンの使い方</span>
                                </div>
                                <div class="page-list__main__table__line__title__time">投稿日:2020-03-16</div>
                            </td>
                        </tr>
                        <tr class="page-list__main__table__line">
                            <td class="page-list__main__table__line__icon">
                                <div><img src="/images_wiki/images/wiki/writer_noel.jpg"><br><span>のえる</span></div>
                            </td>
                            <td class="page-list__main__table__line__title">
                                <div class="page-list__main__table__line__title__text">
                                    <span>各種オーダーの対処</span>
                                </div>
                                <div class="page-list__main__table__line__title__time">投稿日:2020-03-19</div>
                            </td>
                        </tr>
                    </table>
                </div>
            </div>
        </section>

        <section id="index"></section>
    </main>
    <script src="/js/build/wiki/index/index.js"></script>
</body>

</html><?php /**PATH /var/www/kms_content/resources/views/index/index.blade.php ENDPATH**/ ?>