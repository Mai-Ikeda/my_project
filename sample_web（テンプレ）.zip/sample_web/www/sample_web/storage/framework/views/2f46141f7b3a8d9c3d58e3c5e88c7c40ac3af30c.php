<!doctype html>
<html lang="<?php echo e(app()->getLocale()); ?>">

<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
    <title><?php echo e($viewUseVariables["pageTitle"]); ?></title>
    <link rel="stylesheet" href="/css/init.css">
    <link rel="stylesheet" href="/css/guest/index.css">
</head>

<style>
    body {
        width: 100%;
        background-color: black;
    }

    main {
        margin: 0 auto;
        background-color: white;
        font-size: 1.0em;
        background-image: url("<?php echo e(S3_IMG_URL); ?>/guest/background.jpg");
        background-size: 100% auto;
        background-repeat: repeat-y;
    }

    .fit-parent-max {
        width: 100%;
    }

    input.text-form {
        width: 60%;
        padding: 4px;
        margin: 12px;
        font-size: 120%;
        text-align: center;
        border: 1px solid #0005;
        border-radius: 5px;
        color: -internal-light-dark(black, white);
        background-color: white;
    }

    select.select-form {
        padding: 4px;
        margin: 12px;
        font-size: 120%;
        text-align: center;
        border: 1px solid black;
        border-radius: 5px;
        color: -internal-light-dark(black, white);
        background-color: white;
        appearance: menulist;
    }

    div.window-center {
        background-image: url("<?php echo e(S3_IMG_URL); ?>/guest/appraisal_background.jpg");
        background-size: 100% auto;
        background-repeat: repeat-y;
        text-align: center;
        margin: -2% 0;
        padding: 2% 0;
    }

    div.first-view-background {
        position: relative;
        width: 100%;
    }

    div.first-view-background button {
        position: absolute;
        width: 50%;
        left: 25%;
        right: 25%;
        bottom: 0;
    }

    div.first-view-background button img {
        width: 100%;
    }

    button.join-button {
        width: 70%;
        margin-left: 15%;
    }

    button.join-button img {
        width: 100%;
    }

    div.guest-join-button {
        width: 100%;
        margin-top: 1em;
        text-align: center;
        color: blue;
        text-decoration: underline;
    }

    button.appraisal-button {
        width: 40%;
    }
</style>

<body>
    <script>
        //------------------------------//
        // php -> js への変数渡し ここから
        //------------------------------//
    </script>

    <main>

        <section name="firstView">
            <div class="first-view-background">
                <img src="<?php echo e(S3_IMG_URL); ?>/guest/guest_fv.png" class="fit-parent-max">
                <button name="joinButton">
                    <img src="<?php echo e(S3_IMG_URL); ?>/guest/join_button.png">
                </button>
            </div>
            <!-- /firstView -->

            <div name="guestJoinButton" class="guest-join-button">
                <a name="joinButton" href="javascript:void(0);">ログインはこちら</a>
            </div>
            <!-- /guestJoinButton -->
        </section>
        <!-- /firstView -->

        <section name="freeAppraisal">
            <img class="fit-parent-max" src="<?php echo e(S3_IMG_URL); ?>/guest/appraisal_title.jpg">
            <div class="window-center">

                <form name="appraisal" action="/result">

                    <img class="fit-parent-max" src="<?php echo e(S3_IMG_URL); ?>/guest/appraisal_text1.png">
                    <select name="itemcd" class="select-form">
                        <option selected="selected" value="free101">あの人の性格と2人の恋愛運命</option>
                        <option value="free102">あなたの性格とあなたの結婚相手</option>
                        <option value="free103">木下レオンが占う◆2021年の運勢</option>
                    </select>
                    <!-- /itemcd -->

                    <?php echo $__env->make('template/common/form_profile', [ 'viewUseVariables' => $viewUseVariables ] , \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

                    <button name="appraisalButton" class="appraisal-button">
                        <img class="fit-parent-max" src="<?php echo e(S3_IMG_URL); ?>/guest/appraisal_button.png">
                    </button>
                    <!-- /appraisalButton -->

                </form>
                <!-- /appraisal -->
            </div>
            <!-- /appraisal-center -->

            <img class="fit-parent-max" src="<?php echo e(S3_IMG_URL); ?>/guest/appraisal_bottom.jpg">
        </section>
        <!-- /freeAppraisal -->

        <section name="promotion">
            <img class="fit-parent-max" src="<?php echo e(S3_IMG_URL); ?>/guest/guest_promotion_image1.png">
            <img class="fit-parent-max" src="<?php echo e(S3_IMG_URL); ?>/guest/guest_promotion_image2.jpg">
            <button name="joinButton" class="join-button">
                <img src="<?php echo e(S3_IMG_URL); ?>/guest/join_button.png">
            </button>
            <!-- joinButton -->

            <img class="fit-parent-max" src="<?php echo e(S3_IMG_URL); ?>/guest/guest_promotion_image3.jpg">
            <button name="joinButton" class="join-button">
                <img src="<?php echo e(S3_IMG_URL); ?>/guest/join_button.png">
            </button>
            <!-- joinButton -->

            <img class="fit-parent-max" src="<?php echo e(S3_IMG_URL); ?>/guest/guest_promotion_image4.jpg">
            <button name="joinButton" class="join-button">
                <img src="<?php echo e(S3_IMG_URL); ?>/guest/join_button.png">
            </button>
            <!-- joinButton -->

            <img class="fit-parent-max" src="<?php echo e(S3_IMG_URL); ?>/guest/guest_promotion_image5.jpg">
            <img class="fit-parent-max" src="<?php echo e(S3_IMG_URL); ?>/guest/guest_pickup_menu_title1.jpg">
            <div class="window-center">
            </div>
            <img class="fit-parent-max" src="<?php echo e(S3_IMG_URL); ?>/guest/window_bottom.jpg">
            <img class="fit-parent-max" src="<?php echo e(S3_IMG_URL); ?>/guest/guest_pickup_menu_title2.jpg">
            <div class="window-center">
            </div>
            <img class="fit-parent-max" src="<?php echo e(S3_IMG_URL); ?>/guest/window_bottom.jpg">
            <img class="fit-parent-max" src="<?php echo e(S3_IMG_URL); ?>/guest/guest_pickup_menu_title3.jpg">
            <div class="window-center">
            </div>
            <img class="fit-parent-max" src="<?php echo e(S3_IMG_URL); ?>/guest/window_bottom.jpg">

            <button name="joinButton" class="join-button">
                <img src="<?php echo e(S3_IMG_URL); ?>/guest/join_button.png">
            </button>
            <!-- joinButton -->

            <img class="fit-parent-max" src="<?php echo e(S3_IMG_URL); ?>/guest/guest_promotion_image6.jpg">

            <img class="fit-parent-max" src="<?php echo e(S3_IMG_URL); ?>/guest/guest_promotion_image7.jpg">
            <button name="joinButton" class="join-button">
                <img src="<?php echo e(S3_IMG_URL); ?>/guest/join_button.png">
            </button>
            <!-- joinButton -->

            <img class="fit-parent-max" src="<?php echo e(S3_IMG_URL); ?>/guest/guest_promotion_image8.jpg">
            <button name="joinButton" class="join-button">
                <img src="<?php echo e(S3_IMG_URL); ?>/guest/join_button.png">
            </button>
            <!-- joinButton -->
        </section>
        <!-- /promotion -->

        <section id="guest"></section>
    </main>
    <script src="/js/guest/index/index.js"></script>

    <?php echo $__env->make('template/common/layout_switch', compact( "viewUseVariables" ) , \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
</body>

</html><?php /**PATH /var/www/laravell_project/resources/views/guest/index.blade.php ENDPATH**/ ?>