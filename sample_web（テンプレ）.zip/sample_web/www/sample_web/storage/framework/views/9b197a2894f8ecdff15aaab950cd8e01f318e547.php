<!doctype html>
<html lang="<?php echo e(app()->getLocale()); ?>">

<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
    <title></title>
    <link rel="stylesheet" href="/kms_content/css/init.css">
    <link rel="stylesheet" href="/kms_content/css/common/animations.css">
    <link rel="stylesheet" href="/kms_content/css/build/common/index.css">
    <link rel="stylesheet" href="/kms_content/css/build/wiki/index/index.css">
</head>

<?php

use App\Enums\WikiContentCategory;
use App\Models\WikiContent;

$keys = WikiContent::Keys();

?>

<body>
    <script>
        //------------------------------//
        // php -> js への変数渡し ここから
        //------------------------------//
    </script>

    <?php echo $__env->make('template/common/header', compact( "viewUseVariables" ) , \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    <main>
        <section id="loadingLid">
            <transition name="fade">
                <div v-show="show" class="loading-lid">
                    <div class="loading-lid__icon"></div>
                </div>
            </transition>
        </section>

        <?php echo $__env->make('template/common/first_view', compact( "viewUseVariables" ) , \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

        <section name="armySectionJump">
            <div class="asj">
                <a class="asj__box" href="#pageList2">
                    <div class="asj__box__ass">
                        <span>
                            強襲兵装<br>▼
                        </span>
                    </div>
                </a>
                <a class="asj__box" href="#pageList3">
                    <div class="asj__box__hea">
                        <span>
                            重火力兵装<br>▼
                        </span>
                    </div>
                </a>
                <a class="asj__box" href="#pageList4">
                    <div class="asj__box__sho">
                        <span>
                            遊撃兵装<br>▼
                        </span>
                    </div>
                </a>
                <a class="asj__box" href="#pageList5">
                    <div class="asj__box__sup">
                        <span>
                            支援兵装<br>▼
                        </span>
                    </div>
                </a>
            </div>
            <div class="partition-single"></div>
        </section>

        <section name="suiteDescription">
            <div class="sd">

                <div class="sd__title">
                    〜 このサイトについて 〜
                </div>
                <div class="sd__text">
                    このサイトでは PS4 版 BorderBreak 有識者の情報を基軸とした攻略情報を掲載しております。
                    <br>
                    <br>
                    兵装ごとの立ち回りや様々な戦闘ケース、状況、マップ攻略を題材とした情報を掲載しておりますため、よければご覧ください。
                </div>
            </div>
            <div class="partition">
                <div class="partition__border"></div>
            </div>
        </section>

        <?php for ($i = 1; $i <= count($viewUseVariables["wikiContent"]); $i++) { ?>

            <section id="pageList<?= $i ?>" name="<?php
                                                    switch ($i) {
                                                        case WikiContentCategory::MAP: {
                                                                echo "mapPageList";
                                                                break;
                                                            }
                                                        case WikiContentCategory::ASSAULT: {
                                                                echo "assaultPageList";
                                                                break;
                                                            }
                                                        case WikiContentCategory::HEAVY: {
                                                                echo "heavyPageList";
                                                                break;
                                                            }
                                                        case WikiContentCategory::SHORTSTOP: {
                                                                echo "shortstopPageList";
                                                                break;
                                                            }
                                                        case WikiContentCategory::SUPPORT: {
                                                                echo "supportPageList";
                                                                break;
                                                            }
                                                        case WikiContentCategory::UNION: {
                                                                echo "unionPageList";
                                                                break;
                                                            }
                                                    }
                                                    ?>">
                <div class="partition-mono">
                    <div class="partition-mono__title">
                        <div class="partition-mono__title__text">
                            <img src="/kms_content/images/wiki/army<?= $i ?>.png">
                            <?php
                            switch ($i) {
                                case WikiContentCategory::MAP: {
                                        echo "マップ攻略";
                                        break;
                                    }
                                case WikiContentCategory::ASSAULT: {
                                        echo "強襲兵装";
                                        break;
                                    }
                                case WikiContentCategory::HEAVY: {
                                        echo "重火力兵装";
                                        break;
                                    }
                                case WikiContentCategory::SHORTSTOP: {
                                        echo "遊撃兵装";
                                        break;
                                    }
                                case WikiContentCategory::SUPPORT: {
                                        echo "支援兵装";
                                        break;
                                    }
                                case WikiContentCategory::UNION: {
                                        echo "ユニオン攻略";
                                        break;
                                    }
                            }
                            ?>
                        </div>
                    </div>
                    <div class="partition-mono__border"></div>
                </div>

                <div class="page-list">
                    <div class="page-list__main">
                        <table class="page-list__main__table">
                            <tr class="page-list__main__table__column">
                                <th>監修</th>
                                <th>タイトル</th>
                            </tr>
                            <?php for ($j = 0; $j < count($viewUseVariables["wikiContent"][$i]); $j++) { ?>
                                <?php $content = $viewUseVariables["wikiContent"][$i][$j]; ?>

                                <tr class="page-list__main__table__line">
                                    <td class="page-list__main__table__line__icon">
                                        <a href="/wiki/content?id=<?= $content[$keys::ID] ?>">
                                            <div><img src="<?= $content[$keys::ICON] ?>"><br><span><?= $content[$keys::NICKNAME] ?></span></div>
                                        </a>
                                    </td>
                                    <td class="page-list__main__table__line__title">
                                        <a href="/wiki/content?id=<?= $content[$keys::ID] ?>">
                                            <div class="page-list__main__table__line__title__text">
                                                <span><?= $content[$keys::TITLE] ?></span>
                                            </div>
                                            <div class="page-list__main__table__line__title__time">投稿日:<?= $content[$keys::POSTED_AT] ?></div>
                                        </a>
                                    </td>
                                </tr>
                            <?php } ?>
                        </table>
                    </div>
                </div>
            </section>

        <?php } ?>

        <section id="index"></section>
    </main>
    <script src="/kms_content/js/build/common/index.js"></script>
    <script src="/kms_content/js/build/wiki/index/index.js"></script>
</body>

</html><?php /**PATH /var/www/kms_content/resources/views/wiki/index.blade.php ENDPATH**/ ?>