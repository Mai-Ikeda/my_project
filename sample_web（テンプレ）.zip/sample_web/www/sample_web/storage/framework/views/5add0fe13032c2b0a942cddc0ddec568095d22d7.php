<?php if( $viewUseVariables["isMobile"] ): ?>
<style>
    body {
        font-size: 4vw;
    }
</style>
<?php else: ?>
<style>
    body {
        font-size: 20px;
    }
</style>
<?php endif; ?><?php /**PATH /var/www/laravell_project/resources/views/template/common/layout_base_font.blade.php ENDPATH**/ ?>