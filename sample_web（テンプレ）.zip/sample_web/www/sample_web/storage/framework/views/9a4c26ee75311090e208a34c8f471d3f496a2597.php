<section id="pickupMenu" name="pickupMenu">
    <img class="fit-parent-max" src="<?= S3_IMG_URL ?>/member/pickup_menu_title.jpg">
    <slide-show-component slide-datas='<?= $viewUseVariables["pickupMenuImageNames"]; ?>'></slide-show-component>
    <div style="text-align:right;">
        <img style="width: 45%;" src="<?= S3_IMG_URL ?>/member/pickup_menu_show_next.png">
    </div>
</section><?php /**PATH /var/www/laravell_project/resources/views/template/member/index/pickup_menu.blade.php ENDPATH**/ ?>