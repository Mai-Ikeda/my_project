<style>
    div.todays-fortune-center {
        background-image: url("<?= S3_IMG_URL ?>/member/todays_fortune_center.png");
        background-size: 100% auto;
        background-repeat: repeat-y;
        text-align: center;
        margin: -2% 0;
        padding: 2% 0;
        font-size: 130%;
    }

    div.todays-fortune-center p {
        font-weight: bold;
        text-shadow: white 2px 0px 2px, white -2px 0px 2px, white 0px -2px 2px, white -2px 0px 2px;
    }

    a.todays-fortune-text-link {
        width: 90%;
        margin: 0px 5%;
        color: blue;
        text-decoration: underline;
    }
</style>

<img class="fit-parent-max" src="<?= S3_IMG_URL ?>/member/todays_fortune_head.png">
<div class="todays-fortune-center">
    <p>◆2月15日 限定の無料占い◆</p>
    <a class="todays-fortune-text-link" href="javascript:void(0);">正直なところ、今の関係に<br>あの人が抱えている不安と葛藤」</a>
    <p>▲毎日0時に占いが更新されます▲</p>
</div>
<!-- /todays-fortune-center -->

<img class="fit-parent-max" src="<?= S3_IMG_URL ?>/member/todays_fortune_bottom.png"><?php /**PATH /var/www/laravell_project/resources/views/template/member/index/todays_fortune.blade.php ENDPATH**/ ?>