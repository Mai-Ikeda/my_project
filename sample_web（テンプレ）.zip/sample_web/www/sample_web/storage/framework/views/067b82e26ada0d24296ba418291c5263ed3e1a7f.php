<style>
    div.new-menu-center {
        background-image: url("<?= S3_IMG_URL ?>/member/new_menu_center.jpg");
        background-size: 100% auto;
        background-repeat: repeat-y;
        margin: -2% 0;
        padding: 2% 0;
        text-align: center;
        font-family: "ＭＳ Ｐ明朝", "MS PMincho", "ヒラギノ明朝 Pro W3", "Hiragino Mincho Pro", serif;
    }
    div.new-menu-center p {
        font-weight: bold;
        text-align: center;
    }
</style>

<section name="newMenu">
    <img class="fit-parent-max" src="<?= S3_IMG_URL ?>/member/new_menu_title.jpg">
    <div class="new-menu-center">
        <p>※新着メニューは0時に更新※</p>
    </div>
    <!-- /paper-fortune-center -->

    <img class="fit-parent-max" src="<?= S3_IMG_URL ?>/member/new_menu_bottom.jpg">
</section>
<!-- /newMenu --><?php /**PATH /var/www/laravell_project/resources/views/template/member/index/new_menu.blade.php ENDPATH**/ ?>