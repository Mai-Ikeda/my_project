<!doctype html>
<html lang="<?php echo e(app()->getLocale()); ?>">

<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
    <title></title>
    <link rel="stylesheet" href="/css/guest_index.css">
</head>

<style>
    body {
        width: 100%;
        background-color: black;
    }
    main {
        margin: 0 auto;
        background-color: white;
    }
    div.window-center {
        background-image: url("<?php echo e(S3_IMG_URL); ?>/guest/appraisal_background.jpg");
        background-repeat: repeat-y;
        text-align: center;
        margin: -2% 0;
        padding: 2% 0;
    }
    .fit-display-width {
        width: 100%;
    }
    input.text-form {
        width: 60%;
        padding: 4px;
        margin: 12px;
        font-size: 120%;
        text-align: center;
        border: 1px solid #0005;
        border-radius: 5px;
        color: -internal-light-dark(black, white);
        background-color: white;
    }
    select.select-form {
        padding: 4px;
        margin: 12px;
        font-size: 120%;
        text-align: center;
        border: 1px solid black;
        border-radius: 5px;
        color: -internal-light-dark(black, white);
        background-color: white;
        appearance: menulist;
    }
    button.profile-button{
        width: 50%;
    }
</style>
<?php echo $__env->make('template/common/layout_base_font', compact( "viewUseVariables" ) , \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<body>
    <script>
        //------------------------------//
        // php -> js への変数渡し ここから
        //------------------------------//
    </script>

    <main>

        <div class="window-center">
            <form name="profile" action="/profile" method="post">
            <?php echo csrf_field(); ?>
                <div name="fullName">
                    <img class="fit-display-width" src="<?php echo e(S3_IMG_URL); ?>/profile/profile_name_text.jpg">
                    <br>
                    <br>
                    <input type="text" name="full_name" class="text-form" required="required" value='<?php echo e($myProfile["full_name"]); ?>'>
                    <br>
                    <br>
                </div>
                <!-- /fullName -->
                <div name="birthday">
                    <img class="fit-display-width" src="<?php echo e(S3_IMG_URL); ?>/profile/profile_birthday_text.jpg">
                    <br>
                    <br>
                    <input type="text" name="birthday" class="text-form" required="required" value='<?php echo e($myProfile["birthday"]); ?>' style="width: auto;">
                    <br>
                    <br>
                </div>
                <!-- birthday -->
                <button name="" class="profile-button">
                    <img class="fit-display-width" src="<?php echo e(S3_IMG_URL); ?>/profile/profile_button.png">
                </button>
                <!-- /appraisalButton -->

            </form>
            <!-- appraisal -->
        </div>
        <section id="profile"></section>
    </main>
    <?php echo $__env->make('template/common/layout_switch', compact( "viewUseVariables" ) , \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <script src="/js/profile/index.js"></script>
</body>

</html><?php /**PATH /var/www/laravell_project/resources/views/profile/index.blade.php ENDPATH**/ ?>