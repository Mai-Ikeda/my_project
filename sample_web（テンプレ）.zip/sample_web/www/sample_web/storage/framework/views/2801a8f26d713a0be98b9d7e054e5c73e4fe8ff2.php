<section name="firstView">
    <div class="partition">
        <div class="partition__border"></div>
    </div>
    <div class="fv">
        <span class="fv__title">
            <a href="/wiki">
                <p class="fv__title__head">上級者に聞いてみた</p>
                <p class="fv__title__center">BBPS4</p>
                <div class="fv__title__bottom">攻略情報 wiki</div>
            </a>
        </span>
    </div>
    <div class="partition">
        <div class="partition__border"></div>
    </div>
</section><?php /**PATH /var/www/kms_content/resources/views/template/common/first_view.blade.php ENDPATH**/ ?>