<style>
    div.banner-pickup-text-link {
        text-align: center;
    }
    div.banner-pickup-text-link a p {
        width: 90%;
        margin: 0px 5%;
        padding: 2% 0;
        color: white;
        font-size: 90%;
        text-shadow: 0 0 2px black, 0 0 2px black, 0 0 2px black, 0 0 2px black, 0 0 2px black, 0 0 2px black, 0 0 2px black, 0 0 2px black;
        text-decoration: underline;
    }
</style>
<section name="bannerPickup">
    <div class="banner-pickup-text-link">
        <a href="javascript:void(0);">
            <img class="fit-parent-max" src="<?php echo e(S3_IMG_URL); ?>/member/banner_pickup.jpg">
            <p class="banner-pickup-text-link">↑木下レオンが占う◆豪華細密鑑定はコチラから↑</p>
        </a>
    </div>
</section>
<?php /**PATH /var/www/laravell_project/resources/views/template/member/index/banner_pickup.blade.php ENDPATH**/ ?>